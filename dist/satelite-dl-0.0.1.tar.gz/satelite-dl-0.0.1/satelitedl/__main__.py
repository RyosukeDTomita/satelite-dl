import satelitedl

if __name__ == "__main__":
    satelitedl.main()
